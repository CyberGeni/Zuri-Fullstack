firstNumber = int(input("Enter the first number: "))
secondNumber = int(input("Enter the second number: "))
print("The sum of the two numbers is: ", firstNumber + secondNumber)